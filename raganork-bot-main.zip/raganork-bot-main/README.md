# Raganork bot [NPM](https://www.npmjs.com/package/raganork-bot)
NPM package for all bots based on Whatsasena

Installation
`npm i raganork-bot`

Single Package
`"raganork-bot": "x.x.x"`
